using Application.Common.Interfaces;
using Domain.Entities.UserAggregate.Enums;
using Microsoft.EntityFrameworkCore;

namespace Application.SalesRequests.Common;

/// <summary>
/// أهلية الموظف المستهدف للإسناد — ليس عضوية الفرع وحدها.
/// </summary>
public static class SalesRequestEmployeeEligibility
{
    public static async Task<bool> IsEligibleAssigneeAsync(
        IApplicationDbContext db,
        int employeeId,
        int requestBranchId,
        CancellationToken cancellationToken)
    {
        return await db.Users.AsNoTracking()
            .AnyAsync(x =>
                    x.Id == employeeId
                    && x.CreationStep == UserCreationStep.Completed
                    && x.Username != null
                    && x.Username != ""
                    && x.PasswordHash != null
                    && x.PasswordHash != ""
                    && x.UserBranches.Any(b => b.BranchId == requestBranchId),
                cancellationToken);
    }
}
