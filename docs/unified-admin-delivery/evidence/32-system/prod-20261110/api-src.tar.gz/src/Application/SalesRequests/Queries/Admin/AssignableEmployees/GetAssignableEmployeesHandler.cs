using Application.Common.Interfaces;
using Application.SalesRequests.Common;
using Domain.Entities.UserAggregate.Enums;
using Microsoft.EntityFrameworkCore;

namespace Application.SalesRequests.Queries.Admin.AssignableEmployees;

public class GetAssignableEmployeesHandler
    : IRequestHandler<GetAssignableEmployeesQuery, Result<List<AssignableEmployeeItem>>>
{
    private readonly IApplicationDbContext _db;
    private readonly ICurrentUserService _currentUser;

    public GetAssignableEmployeesHandler(IApplicationDbContext db, ICurrentUserService currentUser)
    {
        _db = db;
        _currentUser = currentUser;
    }

    public async Task<Result<List<AssignableEmployeeItem>>> Handle(
        GetAssignableEmployeesQuery request,
        CancellationToken cancellationToken)
    {
        if (!SalesRequestAccess.CanAccessBranch(_currentUser, request.BranchId))
            return SalesRequestErrors.BranchForbidden;

        var query = _db.Users.AsNoTracking()
            .Where(x =>
                x.CreationStep == UserCreationStep.Completed
                && x.Username != null && x.Username != ""
                && x.PasswordHash != null && x.PasswordHash != ""
                && x.UserBranches.Any(b => b.BranchId == request.BranchId));

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(x =>
                (x.FullName != null && x.FullName.Contains(term))
                || (x.Username != null && x.Username.Contains(term)));
        }

        return await query
            .OrderBy(x => x.FullName)
            .Take(50)
            .Select(x => new AssignableEmployeeItem
            {
                Id = x.Id,
                FullName = x.FullName ?? x.Username ?? $"#{x.Id}",
                Username = x.Username
            })
            .ToListAsync(cancellationToken);
    }
}
